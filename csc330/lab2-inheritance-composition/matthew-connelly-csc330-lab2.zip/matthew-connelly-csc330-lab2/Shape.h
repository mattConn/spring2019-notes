// CSC 330 Lab 2
// Matthew Connelly

#pragma once

class Shape
{
	double area = 0;

public:
	Shape(){};

	double calculate_area(){return area;};
};
